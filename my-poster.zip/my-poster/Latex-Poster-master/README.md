# A few words on the  Template:


* To compile the files you have to use Xelatex or Lualatex. PDFLatex won't work.

* For further explanation of the template options consider to read the baposter_guide.pdf.
* If you want to change the template, talk to your colleagues first. Otherwise pls make a fork of this repo.
* The Font-Family Myriad Pro has to be installed on your Operating System.
  
* You can get the Font here: http://www.cufonfonts.com/en/font/492/myriad-pro (alternatively, the Fonts can be found in this repo under "myriad-pro")
  
* On Ubuntu, you may install the Fonts by double-clicking the File and pressing the "install"-button in the top-right corner of the window
  
* You might have to run : sudo apt-get install lcdf-typetools | sudo apt-get install texlive-fonts-extra first
  
* For a detailed installation guide on Windows see: https://www.cedarville.edu/help/Windows-Install-Fonts



After the above mentioned steps, the document should compile just fine.



Myriad Pro is a very elaborate Font-Family. You have nice kerning and things like REAL Smallcaps, which is nice.

Myriad Pro is the official Font-Family for the University of Luebeck.
